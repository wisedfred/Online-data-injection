{
  "Version": "10.72",
  "Servers": [
    {
      "Name": "UDP SERVER ",
      "Flag": "AM.png",
      "ServerIPHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "ServerCloudFrontHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "ServerHTTPHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "ROCKET SPEED SERVER",
      "Flag": "ET.png",
      "ServerIPHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "ServerCloudFrontHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "ServerHTTPHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1194",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "FLASH SPEED 01",
      "Flag": "BJ.png",
      "ServerIPHost": "Xl7QMqJRMzk5G0BvRlUprA==",
      "ServerCloudFrontHost": "Xl7QMqJRMzk5G0BvRlUprA==",
      "ServerHTTPHost": "Xl7QMqJRMzk5G0BvRlUprA==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "SAUDI ( UDP MEGA )",
      "Flag": "SA.png",
      "ServerIPHost": "g2DSFviFsNvM8YmNb+foZw==",
      "ServerCloudFrontHost": "g2DSFviFsNvM8YmNb+foZw==",
      "ServerHTTPHost": "g2DSFviFsNvM8YmNb+foZw==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "FAST SERVER 02",
      "Flag": "AD.png",
      "ServerIPHost": "R9QpFWNyGH2a\/pwrHbtxjw==",
      "ServerCloudFrontHost": "R9QpFWNyGH2a\/pwrHbtxjw==",
      "ServerHTTPHost": "R9QpFWNyGH2a\/pwrHbtxjw==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "HEAVY LOAD SERVER",
      "Flag": "ET.png",
      "ServerIPHost": "WDP\/UmghqE+H5oTFiHnY3w==",
      "ServerCloudFrontHost": "WDP\/UmghqE+H5oTFiHnY3w==",
      "ServerHTTPHost": "WDP\/UmghqE+H5oTFiHnY3w==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "EXTEND LIMIT SERVER",
      "Flag": "AM.png",
      "ServerIPHost": "QzO165nY38FX774DBKekSQ==",
      "ServerCloudFrontHost": "QzO165nY38FX774DBKekSQ==",
      "ServerHTTPHost": "QzO165nY38FX774DBKekSQ==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "5G DATA SWITCH",
      "Flag": "AT.png",
      "ServerIPHost": "H8BsrOrrEtSXMiwsQZ3nsg==",
      "ServerCloudFrontHost": "H8BsrOrrEtSXMiwsQZ3nsg==",
      "ServerHTTPHost": "H8BsrOrrEtSXMiwsQZ3nsg==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "CENTRAL REGION",
      "Flag": "AD.png",
      "ServerIPHost": "bWv1TDEKyGNOFDZgcDqv3w==",
      "ServerCloudFrontHost": "bWv1TDEKyGNOFDZgcDqv3w==",
      "ServerHTTPHost": "bWv1TDEKyGNOFDZgcDqv3w==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "BURMA FAST SERVER ",
      "Flag": "CD.png",
      "ServerIPHost": "NiAKsqQP9xb8qPilFxVarg==",
      "ServerCloudFrontHost": "NiAKsqQP9xb8qPilFxVarg==",
      "ServerHTTPHost": "NiAKsqQP9xb8qPilFxVarg==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1194",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "FINLAND SERVER",
      "Flag": "FI.png",
      "ServerIPHost": "R9QpFWNyGH2a\/pwrHbtxjw==",
      "ServerCloudFrontHost": "R9QpFWNyGH2a\/pwrHbtxjw==",
      "ServerHTTPHost": "R9QpFWNyGH2a\/pwrHbtxjw==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1194",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "ULTRA SERVER",
      "Flag": "ET.png",
      "ServerIPHost": "jDrjLf47icXROfwAN+aBeA==",
      "ServerCloudFrontHost": "jDrjLf47icXROfwAN+aBeA==",
      "ServerHTTPHost": "jDrjLf47icXROfwAN+aBeA==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1193",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "HOT-SPOT SERVER",
      "Flag": "VN.png",
      "ServerIPHost": "zrASuQ6GMtFi+GkGmXvreg==",
      "ServerCloudFrontHost": "zrASuQ6GMtFi+GkGmXvreg==",
      "ServerHTTPHost": "zrASuQ6GMtFi+GkGmXvreg==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1194",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "UGANDA SERVER ",
      "Flag": "UG.png",
      "ServerIPHost": "wjDW7GkIzsg6RCDKESky1A==",
      "ServerCloudFrontHost": "wjDW7GkIzsg6RCDKESky1A==",
      "ServerHTTPHost": "wjDW7GkIzsg6RCDKESky1A==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1194",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "GERMANY SERVER",
      "Flag": "CF.png",
      "ServerIPHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "ServerCloudFrontHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "ServerHTTPHost": "sLhBr9hJBc\/hZDABdxHz+g==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1194",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    },
    {
      "Name": "5G FAST VIP SERVER",
      "Flag": "VN.png",
      "ServerIPHost": "HqFS4zA8hV\/F91lavPYrcA==",
      "ServerCloudFrontHost": "HqFS4zA8hV\/F91lavPYrcA==",
      "ServerHTTPHost": "HqFS4zA8hV\/F91lavPYrcA==",
      "Category": "PREMIUM",
      "OpenVPNTCPPort": "1194",
      "OpenVPNSSLPort": "443",
      "AutoLogin": false,
      "cUsername": "bMc8SGggbilLlZ5VQY2otg==",
      "cPassword": "bMc8SGggbilLlZ5VQY2otg=="
    }
  ],
  "Networks": [
    {
      "Name": "AIRTEL UG || DATA BOOST",
      "Payload": "7G41KjY8rLQe8LDjLTxzyZebAogwuMKR5miIfOECALncPI+lNIfiH7m1hF7ixP+tgMQcbfbpzBHM8oQLG1lVl4Qq1iPNBpnPBztc1hxt6Fi5\/Pi07pxm0MrrETM5RwSz\/+pBKTQk1+fTz3tz0CBSUbnCtUX\/SeuJezH+W5oKdDprKC3CltlXhmpMPByO5GkioAcAzs04BZTyt4W\/VyTg1txOeq\/GA7wlY62GikoX2X\/Rb0Z94M3hOebwFLpmW159U0lRnW2+IyBEOd1iqG5rXebnELh0fuzvyKs8FS+dmu7wR2DE1fV\/3eANlrxXwNre5OE+ifYE8kXbyuFvcmbUU3vffe2EwgvbLR0I2wNf9BNBy4nHIOMCqLKeCyaEqDNi+x+kijGeHIO8bKPdHT2DscQNojqUKGbzBPMB+vesl5UEiI5+3gtr4rqFGhUP2fj22BLSxyhexMuMHvW+0w7J\/9PqZ3V286isyd5I072lPehIFKfCOy7rmPO4xXsPCZxm",
      "Info": "[ All social media unlocked 🔑  ]",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UGANDA (UDP UNLIMITED) ",
      "Payload": "7G41KjY8rLQe8LDjLTxzyZQqL2tYD6n3CGCF2PJwy1W3LZ0r9dAKcoHfcnSknW5SJhKO9yTa8TdNqGiqJN1bH7ZDl8EXz0KannA1UJZxizi79Sxct+7xDlLkHs6EAI5uGDS7cMBOXnY8Pz+Jn5DucaXS4sX5\/Z\/JVkYO9fp5SzxYQlZrEdJtfXh2yaKFG0lOwKozpEUtHQ+vcRVxVmTvJza58NF+SIoF+jKKnISsGeG5XYoe3\/ScnUz+Gde9SSejQsXWETA3hjeRoupMEyDTDN0Z8dd1dSyZuCgJaVUfafiR1S13PwR5eD07HoVC+Gde00ddIszfKf91nLGapibtEG57r49t1lEiIY\/11q3zR5+rP+PL06AuCA8o1zyIVa9s3nDo\/8eJhq3CWBw5aHRIrM1HSTaclpcyWtedrntuencdgdDlosqiTAA3UZwL0TvePvyzapjQV\/sCp2hPsmv5eJPJC4pUmucc8y9eHfRRmwEG9yEHTPaoJ+FVR+vxApHR",
      "Info": "{ High speed internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL ||  BINANCE ACCESS",
      "Payload": "7G41KjY8rLQe8LDjLTxzyYm39csJT5XdqqQE39fyyS2xR9n8AMSrlCTa\/8zJxAKWd0LIg5g3zeaTLPge3JviznPCwL2hWBT9f1HFrDaaNHiZJJv1Es+wTGdliMTK3jU3gC4msNtwysovXAfEdaEhKAHyBZEkw+F10sKa84BAlzOpLy5SljqDt9VnmVVeBwwswUGRzYTy0GTm0h1nXPPLOGwZAZEEN2eBjKO7Ph+FRYJrH5tU0WjnOtO5l5138nVYxjrrQnqLXmlVn+GC7GnnR64TzEOXITJ9UjpDSRHiMlf4aSd2IqrMY+am89lRt32G\/3DRwYmFpUNiEMLVRzCgX8s08INM4\/3dAmzy2q0hr7HKnvhslfMfJd+poJrwEeSJ1mLmuVA6GXJBhs\/9xzYY\/VlaNKYqhB+Fq7+BWa8m6gFsBEOwgkZiGUau8i9P2sYZkVTiJh2DBsqEdj5Ojgcs1x\/MYveTTVnOs2vgla9fcISYPWcoTjyHQs6gflppUpIp",
      "Info": "{ High Speed Internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || BOOSTED X2",
      "Payload": "7G41KjY8rLQe8LDjLTxzySvi6fClu1Mys9vWzxFSVJbZWnYs9jGAmH1KORgCPTxLSqxnvDQkHmQq2gU76kC9JkD3DFpeRytM1rE\/943qwlTe+1fhgZeohejkd1mtSOLzXJfylBjCcVzAeB\/McjfwOaq8oZlc3X8ydms1uoIcz\/4t8Ry7TcsdUmmL6gFCND1U0DsigV1le2OZzBGBkX7xubVLgfJ7f94pu8p8a9cOTjwB3y6W6DZlTcWaZu6MUdjP8LTbSeUfYDkv5S2gmfdYu9\/DZwgAaohezzj30cK+RIH6SA35ipezZ0n5halw4O0yNnEHXe8bWJ6HzaP3i77aGAPVfyVHRRA6GoA0O+cWEml1QEeItQkjfHyRrskh91y7Myph4zsXDklsazEQdxY54hMguc863q3i\/9k6QX+FxfzItml0vIuogcTVcaJfvfiirg1noZBS8sH4TSn9xdWGwu9+QfRT3dbtO\/Lb\/EGarSYQ1uMWr\/9nU\/Rynp4lMxb9",
      "Info": "{ Best network speed }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "Airtel || Central Uganda",
      "Payload": "7G41KjY8rLQe8LDjLTxzyTesVLfetV0ORj\/oSBh6jiIjOLaZepnAtCfgjTE8T8AlOf45Jc46Ra62F5H\/hUfr2HL7eIJf+u4PJtXxbReyzMnTpdmoFYzFJBD\/SsvoIRcLw+lAyo+lTph5ls1pBDm\/DSpbCjWQ+5+YztG9tzKO4KdOcdS8n181EIkEm6MisQfZn6rVnBKruh2GR5hi43Tv3L0xgzIANJtzP4Qg5uOi4J4\/u46nRdXwbEu2Vv0ry160uMP+Ks0fwEKpbRTfRaDBjRPlSoORGL\/L\/u+61OkWm\/P3DlpuHj++dvtaYvRpP2iJxQ62KEJzT5R9\/OBP\/chSfG7z6fzmqL6G5XYKKceCJ4kYxniVJOHBUOvVhDzRHD6zf3VAWtfoOhGri\/cf4xwC2cq9FzM3p2L26\/2PpOXqkaEkMLZLjfhi\/dVhuaFt22AUoJJudptcMLbAXiqtVh3Y2fc7uvU7dt3+8gxOifqTPhjpajbT2YplwvyASIrAwCeL",
      "Info": "{ Best in central region }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "KUWAIT || OOREDOO",
      "Payload": "7G41KjY8rLQe8LDjLTxzyTvm0CgrATkZRfmW5pNydx3d8QpKrS22IqRFz2bzZPi3UUt5dhJdJybKqEjQkVTrF6rcaYQHrCDT0xli\/freI08jzRNfcLvrVKcGOrjyRYxnoYQQ\/0r4BjpoykoxJMKwLfED6YNFK4a8MXh9RFzuzM3UlHqFYly9b7Bk0vink+XP2lEOiQcnRpdZ+ByXVnbFYbSoV2bf0EFOC9lSRH7v8UsjglsiFb2KfOmdPk\/249TEwRRCsNQENzNgh7H0E8fqEa52+ePMx8mfSG6lWoieQWNw02IOeZUYCdjPo42KmU3ekAKGzwtDagDnw\/08ZJ5g7rf+52OcPe+ZJ3\/c5altUpfBdaP858xAqcyLZZBKS1R\/JbgPP+iiTyCGGBrRehEY42cmrm2yb3nPjOJzY2BRw4gASsLGsYdClqIyxvjcjE2qjXtrTW856N9RjdBFQvn40+Wh9gZ\/HT0T2xV0OTkl5Oe3l+OIIUsuoR\/hLc03X0FU",
      "Info": "{ Unlimited internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL || SOCIAL MEDIA",
      "Payload": "7G41KjY8rLQe8LDjLTxzyWiJE6UyUGc4yf48s0ExKb1BHW6Bddv2C8b\/6ojpm+spnB7ekyJIMKBb+Vy66uXZ5j2tNZHXumOU6PjMt4uMntfrP6RV7WvKvoEvF9FxRYAsBQ8G1cyjdRm5wkj8gafgRst+o23HHOBXck9XoF9nMplwTxdRrtlOU7M8JVLqwUNA0W0lyJ9gqzMSaXbJFiHslsstOTUf3HJvZ\/juyJwc3WDqsORElNV42IiZJZLvCXdiEHjSJjBeVT8AmmaiL\/KI0pVNHmuP5tz3UhbyPrF60IcTHC7LMLWniazg1mC3v7XsODEpItlnJbGlkr3opCv\/daYl2Ci83og\/cHMZiWqRkdb06Nm+dD0YVzg\/2JSMKj07hQSsFlXsAIbTP\/1dKTxmCfXt9HlwDxT5LyDUGA01vG46tOkrZJpaeF+WmQ6Qkt4l45KOm3USjiqfmjk+Pi9L6EEzibrkFkPd2Fs4+shEFFKWwhQadk4hT12rirQkp15S",
      "Info": "{ Best for all social media }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "Airtel || Eastern Uganda",
      "Payload": "7G41KjY8rLQe8LDjLTxzyTuUI0CvGH3VcSgqIcBl+OWv2iLYRxvUsop+3I+Md4EB1xsrkW2cJhHK\/C+k4CpJLsRZeUfzgHpEK9jvpntn0VRiG4cFva65G49dnOmBT3tzqbbvGjGk6ue7sXQPD2DLDO5+WtWrCxmiNWe0Rsz9ONA6Qg1b7qjVsA15hRPhEg7fKixJguMem05bLKHXKfSKuN8eioNgB3HrZNbRduLglwv14T+a5ZeDQr85c6zk7FR1IHhJyztlwOBQgDOE1fcD35OnN3HeVcPE8JZVjdBitnYjNGHUfyFpgWkwM6CqbVe6Ijru9YndUs5yfmgw3ciVQBrKU+V\/0gIIBUEjs0Q+1k59ZOq5LhIDbftjSOv3yzURQKz\/Q5dUxIDnZt6wp7gC38UxeEJunax4ujpH9vwqYaZ+y\/dKhXD+9B3+exUBtniO3V07YpA4IckgxGdrYchr+DjlAFTxcfFyZZg1VhKIih1\/2XSoJlDrKiw8cqwd4Khr",
      "Info": "{ Best in Eastern Uganda }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || EXTEND LIMIT",
      "Payload": "7G41KjY8rLQe8LDjLTxzya3RGTYP61eQCd9DKiFs\/FzjxNF3JUqNdwBZ5pQAM+7gvnKkNwtc7VauZ8OBPRnmcpBv2KS0aNISESX1hvPV+e32J8hZGAnSJsNYaf4J2oxdI+hW743bBbPvUhaqcBZBTkgHB1S3FGnoLZJ3OIR8eHZp4q+kk+81GYnlbRrZ0S4e9Fl2iuDR8fnSbMOeK3IMl3JQz1M5mUpvGlUJWonNb8hC1bWC+fB1IF71xpq6Qlkm3Xq89E93oBjuIqQvhgZsOkZl6Hv3kQa7yXM\/SlgRED2PQgmRKe+U66zIGLNbi0teSLaczdKDypsCbQu5kmpnEeF42box+pnAemdLCS0iAR7GRkhrOAR7kts\/DMYG5n4Uv6LY6O+40oKPfGIIGJ6bzu6\/Sx4M+HWkiQzGTqxFqpKGKxKMk4osXNl13q4Bcr32yK0FJx2oidmc6OxARGWd9QJHgacuzwJmCHv3h4vMlygEyWotOEvPkiW6AAQ0ph\/m",
      "Info": "{ Ultra Speed of 2mbps\/ sec. Enjoy Ultra Sonic Speed}",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || FLASH SPEED",
      "Payload": "7G41KjY8rLQe8LDjLTxzyTnVPeEMuRgd0Tc4DqC5128Fh5ADBun1\/tFnRQ759bBJGwD7JdXdo1kMNk+BP19QrSU6PevtLIfU5N8o0iSeUQpEQv3iq9NMec\/VFMPW\/poFTJC+CHJ1\/qd7cX1pdSecv1CO0J2trsUQAwNpK\/2OJUYoLiiXUugZf2+UlTDJo5yvvG9fZKOPdUEnhzss74QslytKUfD++EchUqWhmeO1jhtAivo\/gPWs\/bLtwdLh3ti1pkEtF2eK4CC+Cx15gGtX6OLxf9flpP8Skr7if\/El6g4XfJ9hm7EN0eTGDBx8hqIkwcqDmkJtUt+\/sESrUNeJ95DAdl2tPMKDTBWv+zWLNLptEhlfkP4fi+chUYOgsoKgGKNzrgG0qcO6TFdO9PU6zzuFvdpoFles9lyIuHhFWspTz0cyQ70NKcou0eLSVK4nUEVBdQGAAZ2G2sYIi+A2o7ZsAU5kcaMtUkam3en+EzbsU7EwViHk860PoLJanupF",
      "Info": "{ The Best speed experience }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || 5G SPEED✅️",
      "Payload": "7G41KjY8rLQe8LDjLTxzyfJkF+qgbty+2Nq+1prMgYj2QVsGr0eMtXTnq0Ojvx8rVv16VJjsVbGL2WNITHW\/MaW9WBebyppjJjPAgqvvU2Fu50s+DGbyJ7PHjhXtY9KSf3P9LvW+p6JMgTLu6bC4iLTbMXSetQ0NjFPjOyi\/BXTS\/QbMGkPFcMnKeA1l\/3ZKHDaNlAuDAlesVaA++om0ARbRVvKwtODm1Cej7h3iriZL8xXssa1V1kLXoTSwt5jeSFwecf4DSCQ8kYWbIni9oq5gsL2cwN3GxgGCHLi8u2sSdAqFYrcVUVuAeDVGgftl5YQIYXgb93EV1vNEx6S+P80\/c7Zs9Qg1gXADs19WXMZ3GEbMVcCo7GAQRxzAmo5tEIDqEe+peplDdtoLaYyb0EVuezMJ53hSpELyyd55yoGtXmSkForhQwiPkdku7Y0Jq6rVt1ZAqJTWVcwVrP9QLgTcYMVzYBYc447049heeRvh5gZvRSrXbXhRwTTKyml2",
      "Info": "{ Best network in 2026 }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || HOT SPEED ✅️",
      "Payload": "7G41KjY8rLQe8LDjLTxzyW2jm6GjN5alLYBsfzKGwkHXtXu6JVATXZi2nljmFboWkYyae\/htAIobF6L3aA6qtZYTbbe3J6A7x2kHmob6juPWbefpEJrKc0FK8VKbzES3Mk7OjqbFRctUxuERSedYUk7WtgT7\/Md04nRKx+3lgHW3BD4MXbzaAYBMvsCa32trPB0uDo31H479seufanJe5U3oBHgr9OEfZkjT+tY1gkcHjwmJ7YHDYwkrnJaaV8rESMoCPvyNKU2GimS1NKufin8ieOK3zlOStzN7ve4hA\/3H+Rl13eJhHpyjjc2VhaFBgLPFQk52P2R2ikG8xnyEhtCTePdncFwxbqSXvwNi4Ib9fQSWQrISyAdqv3EF2s+t6Ten\/M9\/8sb2U0AHK0NSfyPyBTglmGY56g2eW1gJDz8SyxKhjP8TCIofb8DfmDPLFk4A+KW99z\/HLUQNkYbazGmRtMIFPLUbZWkckPOXtpyAffQoRMw1GW3Ubg5NVA8j",
      "Info": "{ Enjoy superfast internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL  || APK UPLOAD✅",
      "Payload": "7G41KjY8rLQe8LDjLTxzyZDQBMRwpVlZFkok67JxC4dMxnWG9JkNQFXI70HIjz2u+7M4SCvS5dFEGxD9yHTg9l4i+BfTxYia19XlA2SQDx32cu+ATRuJGO9SBIsXSYXQ7V\/TVesLlRbyJtEEAEoKWz1isni2k7ucHtQVF8TSzhTHkNrUXbfih7+OyQzXM3eaGSU1Hwzb+gcH7I6AbrCn3Om6DOeRfqq\/ES8I+hTWVvpyt0Dh5InnZWZ6QDySznrhwlTGSu1xI6D3lebw8sONMIAyU9lWm0qACUEdNU0rEcM2kz9gBPd4Q\/qiEVnx0kWod+tZnuFBju8tYZe+YIWRdDcMsFpP96Qd5cACwxAO\/hoBUTTqmvQMKOeoNjFepDS66rYTU6WjDp57d7RlomGmuzdmlJx1TktrdGWIvtH2wrtrfei9o5K+qU2rVQ0dozNk\/+monAQLb0Kb9URIEvqHoIYr9D46EvrS+QC9P8GBzAJdcB9pjA30FRH8xsrgRQuD",
      "Info": "{ High Speed Internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "KAMPALA || FRIENDIE",
      "Payload": "7G41KjY8rLQe8LDjLTxzyaIkgp5ZRvT92GiWOM3EdtDgXq0fRsZmPOslqTggPkpZW9yvD3530dxtHBt0jLTFfTplaCk3ssxPLGdck3U93I9d\/2T2sXGvTr4Bb1kam7c\/kMLVzbHa1\/vNws2KBiiOeu0UIW9jT8mxBaofEsdRZ1aWk9RSKuQRIf5Qs6UZl6TTN6zNg+SN9kpIs4QQGjCqA4gNLCm8qoYDIkwe1Yj43Dp4QbqbOl\/+kzjdGZPGumMA3viJue8Tf7ddYiy50xv89x7pukTlB9ZFkw6WQoB7QSLC4ZXbZDlOjlDUUa7qcLmPyR62\/pXJqWY6+Io6fr7EOa2H5V3PD5gaxOXF9psQBqYhA5JD1TIj755fipBHUKQHiSMR9Lh3RF7DCF78OF4UdaoS2mOqTbfs9c\/tJiRj+kHWBebxFdQfQfXEDJPMirqJXYu0bCnhu5m+D1cqJTLQ+cEknNWDwEOnQxn7Asl1ciznZk3un8mdeBkd6je+hyUu",
      "Info": "{ Best in Kampala }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || VIP CLASS A1 ✅️ ",
      "Payload": "7G41KjY8rLQe8LDjLTxzyZebAogwuMKR5miIfOECALncPI+lNIfiH7m1hF7ixP+tgMQcbfbpzBHM8oQLG1lVl4Qq1iPNBpnPBztc1hxt6Fi5\/Pi07pxm0MrrETM5RwSz\/+pBKTQk1+fTz3tz0CBSUbnCtUX\/SeuJezH+W5oKdDprKC3CltlXhmpMPByO5GkioAcAzs04BZTyt4W\/VyTg1txOeq\/GA7wlY62GikoX2X\/Rb0Z94M3hOebwFLpmW159U0lRnW2+IyBEOd1iqG5rXebnELh0fuzvyKs8FS+dmu7wR2DE1fV\/3eANlrxXwNre5OE+ifYE8kXbyuFvcmbUU3vffe2EwgvbLR0I2wNf9BNBy4nHIOMCqLKeCyaEqDNi+x+kijGeHIO8bKPdHT2DscQNojqUKGbzBPMB+vesl5UEiI5+3gtr4rqFGhUP2fj22BLSxyhexMuMHvW+0w7J\/9PqZ3V286isyd5I072lPehIFKfCOy7rmPO4xXsPCZxm",
      "Info": "[ Best for vpn vip groups ]",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "🇦🇪SALAM || SIM FREE",
      "Payload": "7G41KjY8rLQe8LDjLTxzyaIkgp5ZRvT92GiWOM3EdtDgXq0fRsZmPOslqTggPkpZW9yvD3530dxtHBt0jLTFfTplaCk3ssxPLGdck3U93I9d\/2T2sXGvTr4Bb1kam7c\/kMLVzbHa1\/vNws2KBiiOeu0UIW9jT8mxBaofEsdRZ1aWk9RSKuQRIf5Qs6UZl6TTN6zNg+SN9kpIs4QQGjCqA4gNLCm8qoYDIkwe1Yj43Dp4QbqbOl\/+kzjdGZPGumMA3viJue8Tf7ddYiy50xv89x7pukTlB9ZFkw6WQoB7QSLC4ZXbZDlOjlDUUa7qcLmPyR62\/pXJqWY6+Io6fr7EOa2H5V3PD5gaxOXF9psQBqYhA5JD1TIj755fipBHUKQHiSMR9Lh3RF7DCF78OF4UdaoS2mOqTbfs9c\/tJiRj+kHWBebxFdQfQfXEDJPMirqJXYu0bCnhu5m+D1cqJTLQ+cEknNWDwEOnQxn7Asl1ciznZk3un8mdeBkd6je+hyUu",
      "Info": "{ High Speed Internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG UNLIMITED (UDP MEGA)",
      "Payload": "7G41KjY8rLQe8LDjLTxzyZDQBMRwpVlZFkok67JxC4dMxnWG9JkNQFXI70HIjz2u+7M4SCvS5dFEGxD9yHTg9l4i+BfTxYia19XlA2SQDx32cu+ATRuJGO9SBIsXSYXQ7V\/TVesLlRbyJtEEAEoKWz1isni2k7ucHtQVF8TSzhTHkNrUXbfih7+OyQzXM3eaGSU1Hwzb+gcH7I6AbrCn3Om6DOeRfqq\/ES8I+hTWVvpyt0Dh5InnZWZ6QDySznrhwlTGSu1xI6D3lebw8sONMIAyU9lWm0qACUEdNU0rEcM2kz9gBPd4Q\/qiEVnx0kWod+tZnuFBju8tYZe+YIWRdDcMsFpP96Qd5cACwxAO\/hoBUTTqmvQMKOeoNjFepDS66rYTU6WjDp57d7RlomGmuzdmlJx1TktrdGWIvtH2wrtrfei9o5K+qU2rVQ0dozNk\/+monAQLb0Kb9URIEvqHoIYr9D46EvrS+QC9P8GBzAJdcB9pjA30FRH8xsrgRQuD",
      "Info": "{Activated ✅ Non activated use LFH} ",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "OMAN || OOREDOO",
      "Payload": "7G41KjY8rLQe8LDjLTxzyTnVPeEMuRgd0Tc4DqC5128Fh5ADBun1\/tFnRQ759bBJGwD7JdXdo1kMNk+BP19QrSU6PevtLIfU5N8o0iSeUQpEQv3iq9NMec\/VFMPW\/poFTJC+CHJ1\/qd7cX1pdSecv1CO0J2trsUQAwNpK\/2OJUYoLiiXUugZf2+UlTDJo5yvvG9fZKOPdUEnhzss74QslytKUfD++EchUqWhmeO1jhtAivo\/gPWs\/bLtwdLh3ti1pkEtF2eK4CC+Cx15gGtX6OLxf9flpP8Skr7if\/El6g4XfJ9hm7EN0eTGDBx8hqIkwcqDmkJtUt+\/sESrUNeJ95DAdl2tPMKDTBWv+zWLNLptEhlfkP4fi+chUYOgsoKgGKNzrgG0qcO6TFdO9PU6zzuFvdpoFles9lyIuHhFWspTz0cyQ70NKcou0eLSVK4nUEVBdQGAAZ2G2sYIi+A2o7ZsAU5kcaMtUkam3en+EzbsU7EwViHk860PoLJanupF",
      "Info": "{ Supefast internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || WESTERN AREA",
      "Payload": "7G41KjY8rLQe8LDjLTxzyaIkgp5ZRvT92GiWOM3EdtDgXq0fRsZmPOslqTggPkpZW9yvD3530dxtHBt0jLTFfTplaCk3ssxPLGdck3U93I9d\/2T2sXGvTr4Bb1kam7c\/kMLVzbHa1\/vNws2KBiiOeu0UIW9jT8mxBaofEsdRZ1aWk9RSKuQRIf5Qs6UZl6TTN6zNg+SN9kpIs4QQGjCqA4gNLCm8qoYDIkwe1Yj43Dp4QbqbOl\/+kzjdGZPGumMA3viJue8Tf7ddYiy50xv89x7pukTlB9ZFkw6WQoB7QSLC4ZXbZDlOjlDUUa7qcLmPyR62\/pXJqWY6+Io6fr7EOa2H5V3PD5gaxOXF9psQBqYhA5JD1TIj755fipBHUKQHiSMR9Lh3RF7DCF78OF4UdaoS2mOqTbfs9c\/tJiRj+kHWBebxFdQfQfXEDJPMirqJXYu0bCnhu5m+D1cqJTLQ+cEknNWDwEOnQxn7Asl1ciznZk3un8mdeBkd6je+hyUu",
      "Info": "{ Best in Western Uganda }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL UG || HEAVY LOAD",
      "Payload": "7G41KjY8rLQe8LDjLTxzyd1Imi9imoXzfY2XgHdKoa0dizT4Hdnck3TkC0+oLhsz8rOLiKz0vUHTE65PdO47gWafm8iPp0mTUl121ZzKIvgZQpwuRa9g+LNPEAANFwXoUTumDG4XysVpPE\/jOvQe4kAPionUEf2hTMRMW3dEz68RRBFF8XtfcaCxm6XuNPItuDW9on\/HGxMawa+QEPf7hERdPJDjZkkTFXdJjYHSlP091OdZZxzYma2lD1GY4pTkbYQKoyXrNAatY7RacKAeSrRAwD0vTgGeTyaVC7LfXcGlXZvoS+3qgt+p9fBDG29Eoz1kkALVlF\/46SjLIF4F9Wfd0kiqbuguZawARZURyndC4wY6Ykc5V+at4+tkSs7WscjqfAxap+kH+UuE2i\/EBS\/iBjPfq\/OavEy1m1y+jWHZHCiYgzP6QugMYY+TlpXmIvO55Gy64sfPdLK3DoT8\/UusOGEck1hcMa2yzfjqmoEjjNihGvbsHzNynQjw1jey",
      "Info": "{ High Speed Internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "WORLD 5G INTERNET",
      "Payload": "7G41KjY8rLQe8LDjLTxzyZQqL2tYD6n3CGCF2PJwy1W3LZ0r9dAKcoHfcnSknW5SJhKO9yTa8TdNqGiqJN1bH7ZDl8EXz0KannA1UJZxizi79Sxct+7xDlLkHs6EAI5uGDS7cMBOXnY8Pz+Jn5DucaXS4sX5\/Z\/JVkYO9fp5SzxYQlZrEdJtfXh2yaKFG0lOwKozpEUtHQ+vcRVxVmTvJza58NF+SIoF+jKKnISsGeG5XYoe3\/ScnUz+Gde9SSejQsXWETA3hjeRoupMEyDTDN0Z8dd1dSyZuCgJaVUfafiR1S13PwR5eD07HoVC+Gde00ddIszfKf91nLGapibtEG57r49t1lEiIY\/11q3zR5+rP+PL06AuCA8o1zyIVa9s3nDo\/8eJhq3CWBw5aHRIrM1HSTaclpcyWtedrntuencdgdDlosqiTAA3UZwL0TvePvyzapjQV\/sCp2hPsmv5eJPJC4pUmucc8y9eHfRRmwEG9yEHTPaoJ+FVR+vxApHR",
      "Info": "{ All countries test }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "Airtel || Northern Uganda",
      "Payload": "7G41KjY8rLQe8LDjLTxzyd1Imi9imoXzfY2XgHdKoa0dizT4Hdnck3TkC0+oLhsz8rOLiKz0vUHTE65PdO47gWafm8iPp0mTUl121ZzKIvgZQpwuRa9g+LNPEAANFwXoUTumDG4XysVpPE\/jOvQe4kAPionUEf2hTMRMW3dEz68RRBFF8XtfcaCxm6XuNPItuDW9on\/HGxMawa+QEPf7hERdPJDjZkkTFXdJjYHSlP091OdZZxzYma2lD1GY4pTkbYQKoyXrNAatY7RacKAeSrRAwD0vTgGeTyaVC7LfXcGlXZvoS+3qgt+p9fBDG29Eoz1kkALVlF\/46SjLIF4F9Wfd0kiqbuguZawARZURyndC4wY6Ykc5V+at4+tkSs7WscjqfAxap+kH+UuE2i\/EBS\/iBjPfq\/OavEy1m1y+jWHZHCiYgzP6QugMYY+TlpXmIvO55Gy64sfPdLK3DoT8\/UusOGEck1hcMa2yzfjqmoEjjNihGvbsHzNynQjw1jey",
      "Info": "{ Best in Northern Uganda }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "MOVIE TIME || FRIENDIE ",
      "Payload": "7G41KjY8rLQe8LDjLTxzyd1Imi9imoXzfY2XgHdKoa0dizT4Hdnck3TkC0+oLhsz8rOLiKz0vUHTE65PdO47gWafm8iPp0mTUl121ZzKIvgZQpwuRa9g+LNPEAANFwXoUTumDG4XysVpPE\/jOvQe4kAPionUEf2hTMRMW3dEz68RRBFF8XtfcaCxm6XuNPItuDW9on\/HGxMawa+QEPf7hERdPJDjZkkTFXdJjYHSlP091OdZZxzYma2lD1GY4pTkbYQKoyXrNAatY7RacKAeSrRAwD0vTgGeTyaVC7LfXcGlXZvoS+3qgt+p9fBDG29Eoz1kkALVlF\/46SjLIF4F9Wfd0kiqbuguZawARZURyndC4wY6Ykc5V+at4+tkSs7WscjqfAxap+kH+UuE2i\/EBS\/iBjPfq\/OavEy1m1y+jWHZHCiYgzP6QugMYY+TlpXmIvO55Gy64sfPdLK3DoT8\/UusOGEck1hcMa2yzfjqmoEjjNihGvbsHzNynQjw1jey",
      "Info": "{ Watch one movie to save limit }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "AIRTEL || 5G DATA SWITCH",
      "Payload": "OHD8G+CnqR3YmnqCsOuNU28+pPjaqdrdtjAAniRRjCK8PDadoFSqYebunyfLXm4flWj2d5G6XDJsdYxOgs26vkYHX4CyuxoBV\/v9I2xuS0hiQAddOgIDmxmtccMzWzXeZkxS30W9KsdEPh4cha+fWUaAS9m+cA99AxYuI5wzM0yvBmH24sakkdjYjcUcRsH8cmX8j08w3rExcavqnoFLX0ooOGcvT30ZGvkbk84FHdysMz23ZhDQO3ROkPir9w\/quOOvGLJ2SI6v\/sHYlGUyxaHRrgmlr4PHTfcXIQP5f5DLfL4wglIlsFo22IPzG+xL1FjFa\/74txORu3mGvn0MwithdRqNRKDy\/\/jSA\/JtABlGtbPpm5F2hbh175\/rbf+D66kjMoyJ+TCs0OAlEYfZTQZeGvtyJnnI5HtkkcRPFBwsfzwoH7z\/ct6ZkEgvB5ay",
      "Info": "{ High speed internet }",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "TESTING PHASE",
      "Payload": "7G41KjY8rLQe8LDjLTxzyYm39csJT5XdqqQE39fyyS2xR9n8AMSrlCTa\/8zJxAKWd0LIg5g3zeaTLPge3JviznPCwL2hWBT9f1HFrDaaNHiZJJv1Es+wTGdliMTK3jU3998vM9kvzgI8P22GpBY7vP4nWNtt4slmm4P2mDrO+suSfSCqAuEYg6uz6EWbA6qdyiV1V4y\/IXgEl2jbNQuDvsOCHihQmI5P92NvDMZIvMXlJrB2Rthm26CzHnxyNHhBVJbu73zmZv6mwRQWsU8IUaApSBAIvHwTUcRCQsBJImdoxp5o8051ocF6KaeMF0+vDsCJqVx9OqKjq81EKTvKdMjIviQrdKaLjeg9sLkLWRysLVRm5b68UO8++\/I69QNC1bcMgUoMoBI8i3BktpkQ957yPU6rn3S2xt91Zng+7vxqhU873m7tKhJEvpRTvFcuVaZRgISvKZ9sGfK5KmtCjCAENCnSWNeB2UDT0he6lIanYTkPBnNDYup0iBCjMzo8Ka6\/F3o4ku3KH8UpeHrTfA==",
      "Info": "Don't use",
      "TunnelType": 6,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    },
    {
      "Name": "🇸🇦 || Zain free All area",
      "Payload": "c3SG5s81XtbJOXTKStVCKxz6+FSYTe1BHVi3xgA8U7uZLi3+3cf8WQT2e4Jirs\/tZV9R4WuC6AZdD\/02b4YlpXe4cE7VdtJxPzSeE7GmDcikvPKK0+PBI27ORRQ7POx28HFJaV5HacOgJ1TLvDVByBCGt4PC5wCYk8O3Poq\/4WQ=",
      "Info": "( Working 100% )",
      "TunnelType": 2,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "+0EebVRagEv93M+DtqfCCA==",
        "Port": "80"
      }
    },
    {
      "Name": "🇸🇦 || Jawwy free 💯",
      "Payload": "c3SG5s81XtbJOXTKStVCKxz6+FSYTe1BHVi3xgA8U7uZLi3+3cf8WQT2e4Jirs\/tZV9R4WuC6AZdD\/02b4YlpXe4cE7VdtJxPzSeE7GmDcikvPKK0+PBI27ORRQ7POx28HFJaV5HacOgJ1TLvDVByBCGt4PC5wCYk8O3Poq\/4WQ=",
      "Info": "High Speed Internet ",
      "TunnelType": 2,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "MnzPUSbWDwiip8Pl6idAqOcMACdgxCT7obRvEFA5Mxs=",
        "Port": "80"
      }
    },
    {
      "Name": "🇸🇦 || Mobily free ",
      "Payload": "c3SG5s81XtbJOXTKStVCKxz6+FSYTe1BHVi3xgA8U7uZLi3+3cf8WQT2e4Jirs\/tZV9R4WuC6AZdD\/02b4YlpXe4cE7VdtJxPzSeE7GmDcikvPKK0+PBI27ORRQ7POx28HFJaV5HacOgJ1TLvDVByBCGt4PC5wCYk8O3Poq\/4WQ=",
      "Info": "Saudi Arabia connect ",
      "TunnelType": 2,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "BBgiV4N\/fp8nGV8ziu9wjw==",
        "Port": "80"
      }
    },
    {
      "Name": "🇯🇴 || Etisalat 👉 JioSaavn Pack ",
      "Payload": "dmKTeAAiWUFB1qCHKFhfsk2zrr89t8J4ABuYEiITLtySJvgpAjgvHrzZtdZiTkcYmNCuXYKwOoBy+dp9YtkwyBQgCnrugc4F37njAjiL7pf6WFQw7x6dwqnHVwRmfBrb2l93PNy07CsUOlhbBTLIR86V0E1fDvTb\/HdRvc7M1A3VSjYZSbpDv1XnK4UzO8jwTQHLQGYuheht3VEQT9uAx3vmt\/zKAiB5kwznLFYd1TdkfLxHIcnaPYj3Kzq5vbTOGtRAuG2pphXp\/s1drkAH\/KNCCzPidimPNDga2icGxEoYR4702Osfy7yk\/Kb9w+mLgh8KRlrJUCbLZ6bwMuXNEALToKx2kCx5zuad6PfFCqs=",
      "Info": "Etisalat free",
      "TunnelType": 2,
      "FrontQuery": "",
      "BackQuery": "",
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": "80"
      }
    }
  ],
  "SSLNetworks": [
    {
      "Name": "LYCA MOBILE 5G SPEED",
      "SNIHost": "KpSCa+OEkbdDcXdq3i9e2Hce4xsibHasT16r878UI8E=",
      "Payload": "bMc8SGggbilLlZ5VQY2otg==",
      "Info": "Load a little data of 250shs to enjoy unlimitedly",
      "TunnelType": 3,
      "Priority": 0,
      "ServerHostDNS": "cf",
      "ProxySettings": {
        "Squid": "UzyGPIZj2ewyJt+uuJX15w==",
        "Port": ""
      }
    }
  ],
  "Username": "",
  "Password": "",
  "Notes": "HELLO MEDOCAS USERS.\n\n\nMore users call for more servers to maintain fast speed.\n\n\nCurrently, we are upgrading all our servers each new update.\n\n\nMuch appreciation to Medocas Admins, Sub Admins, Resellers and users for combined efforts ❤️ \n\n\nThanks for your support "
}